package many.launcher.jabberwock;

import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.webkit.WebView;

public class JabbActivity extends Activity {
	private MediaPlayer mus;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_jabb);
		WebView myWebView = (WebView) findViewById(R.id.webView3);
				
		myWebView.loadUrl("file:///android_asset/jabberwocky.html");
	
	}
	
	@Override
	protected void onResume() {

		mus = MediaPlayer.create(this, R.raw.backmusic);
		mus.setLooping(true);
		mus.start();
		super.onResume();
	}

	@Override
	protected void onPause() {
		mus.stop();
		mus.release();
		super.onPause();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.jabb, menu);
		return true;
	}
	
	public void openLV(View v) {
		String url = "http://en.wikipedia.org/wiki/Jabberwocky";
		Intent i = new Intent(Intent.ACTION_VIEW);
		i.setData(Uri.parse(url));
		startActivity(i);
	}
	
	public void openAboutActivity(View V) {
		Intent intent = new Intent(JabbActivity.this, AboutActivity.class);
		startActivity(intent);
	}

}
