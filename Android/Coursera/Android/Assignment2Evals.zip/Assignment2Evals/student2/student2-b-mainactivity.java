package coursera.assignments.tictactoe;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener {
	
	private ImageView imageNo1, imageNo2, imageNo3, imageNo4, imageNo5, imageNo6, imageNo7, imageNo8, imageNo9;
	
	private boolean crabPlayer = true;
	private boolean win = false;
	
	private int fieldNumbers[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
	
	private int playerOne[] = { 0, 0, 0, 0, 0, 0, 0, 0, 0 }; // crab player
	private int playerTwo[] = { 0, 0, 0, 0, 0, 0, 0, 0, 0 }; // shark player
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		// Find image views and set listeners
		this.imageNo1 = (ImageView) findViewById(R.id.imageNo1);
		this.imageNo1.setOnClickListener(this);
		
		this.imageNo2 = (ImageView) findViewById(R.id.imageNo2);
		this.imageNo2.setOnClickListener(this);
		
		this.imageNo3 = (ImageView) findViewById(R.id.imageNo3);
		this.imageNo3.setOnClickListener(this);
		
		this.imageNo4 = (ImageView) findViewById(R.id.imageNo4);
		this.imageNo4.setOnClickListener(this);
		
		this.imageNo5 = (ImageView) findViewById(R.id.imageNo5);
		this.imageNo5.setOnClickListener(this);
		
		this.imageNo6 = (ImageView) findViewById(R.id.imageNo6);
		this.imageNo6.setOnClickListener(this);
		
		this.imageNo7 = (ImageView) findViewById(R.id.imageNo7);
		this.imageNo7.setOnClickListener(this);
		
		this.imageNo8 = (ImageView) findViewById(R.id.imageNo8);
		this.imageNo8.setOnClickListener(this);
		
		this.imageNo9 = (ImageView) findViewById(R.id.imageNo9);
		this.imageNo9.setOnClickListener(this);
		
	}

	public void newGame(View v) {
		
		for (int i = 0; i < this.fieldNumbers.length;  i++) 
			this.fieldNumbers[i]=i+1;
		
		for (int i = 0; i < this.playerOne.length; i++) 
			this.playerOne[i]=0;
		
		for (int i = 0; i < this.playerTwo.length; i++) 
			this.playerTwo[i]=0;
		
		win = false;
		
		this.imageNo1.setImageResource(R.drawable.white);
		this.imageNo2.setImageResource(R.drawable.white);
		this.imageNo3.setImageResource(R.drawable.white);
		this.imageNo4.setImageResource(R.drawable.white);
		this.imageNo5.setImageResource(R.drawable.white);
		this.imageNo6.setImageResource(R.drawable.white);
		this.imageNo7.setImageResource(R.drawable.white);
		this.imageNo8.setImageResource(R.drawable.white);
		this.imageNo9.setImageResource(R.drawable.white);
	}
	
	@Override
	public void onClick(View v) {
		
		if (v == this.imageNo1) click(1, this.imageNo1);
		if (v == this.imageNo2) click(2, this.imageNo2);
		if (v == this.imageNo3) click(3, this.imageNo3);
		if (v == this.imageNo4) click(4, this.imageNo4);
		if (v == this.imageNo5) click(5, this.imageNo5);
		if (v == this.imageNo6) click(6, this.imageNo6);
		if (v == this.imageNo7) click(7, this.imageNo7);
		if (v == this.imageNo8) click(8, this.imageNo8);
		if (v == this.imageNo9) click(9, this.imageNo9);
		
	}

	public void click(int position, ImageView v) {
		
		if (this.win == false) {
			
			if (isFieldClickable(position)) {
				
				this.fieldNumbers[position - 1] = 0;
				
				if (this.crabPlayer) {
					
					v.setImageResource(R.drawable.crab);
					this.playerOne[position - 1] = position;
					win(this.playerOne);
						
				} else {
					
					v.setImageResource(R.drawable.shark);
					this.playerTwo[position - 1] = position;
					win(this.playerTwo);
				}
				
				this.crabPlayer = !this.crabPlayer;
			}
		}
	}

	public void win(int[] i) {
		
		if (check(1, 2, 3, i)) win = true;
		if (check(4, 5, 6, i)) win = true;
		if (check(7, 8, 9, i)) win = true;
		if (check(1, 4, 7, i)) win = true;
		if (check(2, 5, 8, i)) win = true;
		if (check(3, 6, 9, i)) win = true;
		if (check(1, 5, 9, i)) win = true;
		if (check(7, 5, 3, i)) win = true;
		
		if(this.win){
			if(this.crabPlayer)
				Toast.makeText(MainActivity.this, "Mr.Crab Won! Woohoo!", Toast.LENGTH_LONG).show();
			else
				Toast.makeText(MainActivity.this, "Mr.Shark Won! Woohoo!", Toast.LENGTH_LONG).show();
		}
	}

	public boolean check(int a, int b, int c, int[] niz) {
		
		if ((niz[a - 1] != 0) && (niz[b - 1] != 0) && (niz[c - 1] != 0))
			return true;
		return false;
	}

	public boolean isFieldClickable(int position) {
		
		for (int i = 0; i < this.fieldNumbers.length; i++) {
			if (this.fieldNumbers[i] == position)
				return true;
		}
		
		return false;
	}

}
