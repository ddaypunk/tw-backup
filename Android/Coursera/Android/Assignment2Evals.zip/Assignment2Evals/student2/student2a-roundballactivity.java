package coursera.assignments.appsapplenty;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.webkit.WebView;

public class RoundballActivity extends Activity {

	private static String contentURL = "file:///android_asset/roundball/roundball.html";
	
	private WebView webView;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_roundball);
		
		//Find web view
		this.webView = (WebView)findViewById(R.id.roundballWebView);
		
		this.webView.getSettings().setJavaScriptEnabled(true);
		this.webView.getSettings().setDomStorageEnabled(true);
						
		// Load content
		this.webView.loadUrl(contentURL);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.roundball, menu);
		return true;
	}

}
