package coursera.assignments.appsapplenty;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;

public class JabberwockyActivity extends Activity {

	private static String contentURL = "file:///android_asset/jabberwocky.html";
	private static String imageURL = "file:///android_asset/jabberwockyImage.html";
	private static String wikipediaURL = "http://en.wikipedia.org/wiki/Jabberwocky";
	
	private WebView webView;
	private MediaPlayer mediaPlayer;
	
	private boolean showingPicture=false;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_jabberwocky);
		
		//Find web view
		this.webView = (WebView)findViewById(R.id.JabberwockyWebView);
		
		// Load content
		this.webView.loadUrl(contentURL);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.jabberwocky, menu);
		return true;
	}

	public void openWikipedia(View v) {
		
		Intent intent = new Intent(Intent.ACTION_VIEW);
		intent.setData(Uri.parse(wikipediaURL));

		startActivity(intent);
	}
	
	public void openPicture(View v) {
		
		//Find web view
		if(this.webView==null)
			this.webView = (WebView)findViewById(R.id.JabberwockyWebView);
				
		Button button = (Button)findViewById(R.id.pictureButton);
		
		// Load content
		if(this.showingPicture){
			
			this.webView.loadUrl(contentURL);
			
			button.setText(R.string.btnTitle_show_picture);
			
			this.showingPicture=false;
			
		}else{
			
			this.webView.loadUrl(imageURL);
			
			button.setText(R.string.btnTitle_show_song);
			
			this.showingPicture=true;
			
		}
		
	}
	
	@Override
	protected void onResume() {
		
		this.mediaPlayer = MediaPlayer.create(this, R.raw.music);
		this.mediaPlayer.setLooping(true);
		
		this.mediaPlayer.start();
		
		super.onResume();
	}

	@Override
	protected void onPause() {
		
		this.mediaPlayer.stop();
		this.mediaPlayer.release();
		
		super.onPause();
	}

}
